/**
 * @description Account trigger — single trigger per object, all logic
 *              delegated to AccountTriggerHandler.
 *
 * @author      Lokesh Pagidigommula
 * @since       2024-01-01
 */
trigger AccountTrigger on Account (
    before insert, before update, before delete,
    after insert,  after update,  after delete,  after undelete
) {
    new AccountTriggerHandler().run();
}
