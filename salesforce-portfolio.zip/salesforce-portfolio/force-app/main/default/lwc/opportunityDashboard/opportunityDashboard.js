import { LightningElement, wire, track } from 'lwc';
import { NavigationMixin }              from 'lightning/navigation';
import { ShowToastEvent }              from 'lightning/platformShowToastEvent';
import { refreshApex }                 from '@salesforce/apex';

import getOpportunityMetrics from '@salesforce/apex/OpportunityDashboardController.getOpportunityMetrics';
import getTopDeals           from '@salesforce/apex/OpportunityDashboardController.getTopDeals';

/**
 * @description Opportunity Dashboard LWC — real-time metrics and top deal tracking.
 *              Demonstrates wire service, Apex integration, event handling,
 *              conditional rendering, and LDS usage.
 *
 * @author      Lokesh Pagidigommula
 */
export default class OpportunityDashboard extends NavigationMixin(LightningElement) {

    // ─────────────────────────────────────────────────────────────────────────
    // State
    // ─────────────────────────────────────────────────────────────────────────

    @track selectedStage = '';
    @track selectedOwnerId = '';
    @track isLoading = false;

    _metricsWireResult;
    _dealsWireResult;

    // ─────────────────────────────────────────────────────────────────────────
    // Wire adapters
    // ─────────────────────────────────────────────────────────────────────────

    @wire(getOpportunityMetrics, {
        stage:   '$selectedStage',
        ownerId: '$selectedOwnerId'
    })
    wiredMetrics(result) {
        this._metricsWireResult = result;
        if (result.error) {
            this.handleError('Failed to load metrics', result.error);
        }
    }

    @wire(getTopDeals, {
        stage:   '$selectedStage',
        ownerId: '$selectedOwnerId',
        limit:   10
    })
    wiredDeals(result) {
        this._dealsWireResult = result;
        if (result.error) {
            this.handleError('Failed to load top deals', result.error);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Getters
    // ─────────────────────────────────────────────────────────────────────────

    get metrics() {
        return this._metricsWireResult?.data;
    }

    get topDeals() {
        return this._dealsWireResult?.data ?? [];
    }

    get hasDeals() {
        return this.topDeals.length > 0;
    }

    get totalValueFormatted() {
        if (!this.metrics) return '$0';
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD',
            notation: 'compact',
            maximumFractionDigits: 1
        }).format(this.metrics.totalValue);
    }

    get stageOptions() {
        return [
            { label: 'All Stages',         value: '' },
            { label: 'Prospecting',         value: 'Prospecting' },
            { label: 'Qualification',       value: 'Qualification' },
            { label: 'Proposal/Price Quote',value: 'Proposal/Price Quote' },
            { label: 'Negotiation/Review',  value: 'Negotiation/Review' },
            { label: 'Closed Won',          value: 'Closed Won' },
        ];
    }

    get dealColumns() {
        return [
            { label: 'Opportunity Name', fieldName: 'recordUrl', type: 'url',
              typeAttributes: { label: { fieldName: 'Name' }, target: '_blank' } },
            { label: 'Account',   fieldName: 'AccountName', type: 'text' },
            { label: 'Stage',     fieldName: 'StageName',   type: 'text' },
            { label: 'Amount',    fieldName: 'Amount',      type: 'currency',
              typeAttributes: { currencyCode: 'USD' } },
            { label: 'Close Date', fieldName: 'CloseDate',  type: 'date' },
            { label: 'Probability', fieldName: 'Probability', type: 'percent' },
        ];
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Handlers
    // ─────────────────────────────────────────────────────────────────────────

    handleStageChange(event) {
        this.selectedStage = event.detail.value;
    }

    handleOwnerChange(event) {
        this.selectedOwnerId = event.detail.value[0] ?? '';
    }

    handleRowAction(event) {
        const { action, row } = event.detail;
        if (action.name === 'view') {
            this[NavigationMixin.Navigate]({
                type: 'standard__recordPage',
                attributes: { recordId: row.Id, actionName: 'view' }
            });
        }
    }

    async handleRefresh() {
        this.isLoading = true;
        try {
            await Promise.all([
                refreshApex(this._metricsWireResult),
                refreshApex(this._dealsWireResult)
            ]);
            this.showToast('Refreshed', 'Dashboard updated successfully.', 'success');
        } catch (error) {
            this.handleError('Refresh failed', error);
        } finally {
            this.isLoading = false;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Private helpers
    // ─────────────────────────────────────────────────────────────────────────

    handleError(title, error) {
        const message = error?.body?.message ?? error?.message ?? 'An unexpected error occurred.';
        this.showToast(title, message, 'error');
        console.error(`[OpportunityDashboard] ${title}:`, error);
    }

    showToast(title, message, variant) {
        this.dispatchEvent(new ShowToastEvent({ title, message, variant }));
    }
}
