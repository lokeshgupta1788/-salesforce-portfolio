# Architecture Patterns & Design Decisions

> Reference guide to the patterns used in this repository, with rationale.

---

## 1. Trigger Handler Framework

**Pattern**: Single trigger per object → TriggerHandler base class → Concrete handler → Service layer

```
AccountTrigger.trigger
    └── new AccountTriggerHandler().run()
            ├── beforeInsert()  → AccountService.setDefaultSegment()
            ├── afterInsert()   → AccountService.createDefaultOpportunity()
            └── afterUpdate()   → AccountService.syncRatingToOpportunities()
```

**Why**:
- One trigger per object prevents ordering issues and conflicts
- Handler pattern makes logic unit-testable without real DML
- Service layer enforces separation of concerns
- `TriggerHandler.bypass()` enables safe data migrations without disabling automation

**Key classes**: `TriggerHandler.cls`, `AccountTriggerHandler.cls`

---

## 2. Batch Apex for Large Datasets

**Pattern**: `Database.Batchable` + `Database.Stateful` + Platform Events for async notification

```
Scheduled Job
    └── Database.executeBatch(new BatchLoyaltyProcessor(), 200)
            ├── start()    → QueryLocator (cursor-based, governor-safe)
            ├── execute()  → Chunk processing, partial success via Database.update(false)
            └── finish()   → Summary email + Queueable retry for errors
```

**Why**:
- Stateful interface accumulates metrics across batches
- `Database.update(false)` allows partial success — one bad record doesn't fail the batch
- Platform Events decouple downstream notifications
- Batch size of 200 balances throughput against governor limits (150 SOQL per transaction)

**Key classes**: `BatchLoyaltyProcessor.cls`

---

## 3. REST Integration with Named Credentials

**Pattern**: Named Credential → Service class → Retry with exponential backoff → Error log

```
Business Logic
    └── RestApiCalloutService.post('BankingCore', '/customers', payload)
            ├── HttpRequest (callout:NamedCredential/endpoint)
            ├── Retry loop (max 3x, codes 429/503/504)
            └── Integration_Error_Log__c insert on failure
```

**Why**:
- Named Credentials avoid hardcoded endpoints and handle OAuth token refresh automatically
- Retry logic handles transient failures from upstream systems (rate limits, timeouts)
- Error logging table enables ops team monitoring without code access
- Service class is mockable for unit testing (`HttpCalloutMock`)

**Key classes**: `RestApiCalloutService.cls`

---

## 4. Lightning Web Component Architecture

**Pattern**: Wire adapters → Reactive properties → Child component events → Parent handler

```
opportunityDashboard (parent)
    ├── @wire(getOpportunityMetrics)   — reactive: stage, ownerId
    ├── @wire(getTopDeals)             — reactive: stage, ownerId
    ├── lightning-datatable            — onrowaction → handleRowAction
    └── NavigationMixin.Navigate       — deep link to record pages
```

**Why**:
- Wire service handles cache invalidation and reactivity automatically
- `refreshApex()` provides manual refresh without component re-render
- `NavigationMixin` ensures navigation works across all Lightning contexts (App, Community, Mobile)
- Toast notifications provide consistent UX feedback

**Key files**: `opportunityDashboard/`

---

## 5. CI/CD Pipeline Strategy

**Pattern**: Feature Branch → PR → Scratch Org validation → Develop (UAT) → Main (Prod)

```
feature/* ──PR──► develop ──auto──► UAT Sandbox
                                          │
main ◄──PR+approval──────────────────────┘
  │
  └──auto──► Production (with approval gate)
```

**Why**:
- Scratch orgs provide clean, isolated environments for every PR validation
- `RunLocalTests` on UAT catches integration issues early
- GitHub Environment protection rules enforce manual approval before Production
- Secrets management via GitHub Actions secrets keeps auth URLs out of code

**Key files**: `.github/workflows/salesforce-ci-cd.yml`

---

## 6. Security Model

**Principle**: Least-privilege by default, compliance-first

| Layer | Implementation |
|---|---|
| Record access | OWD + Role Hierarchy + Sharing Rules |
| Field access | Field-Level Security on all Profiles + Permission Sets |
| Data encryption | Shield Platform Encryption on PII fields |
| Compliance | SOX audit trail, HIPAA field history, PCI-DSS for payment data |
| Monitoring | Event Monitoring + Transaction Security Policies |

---

## Anti-Patterns Avoided

| ❌ Anti-pattern | ✅ What we do instead |
|---|---|
| Multiple triggers per object | Single trigger + handler |
| SOQL inside loops | Bulk queries before loops, maps for lookups |
| Hardcoded IDs/endpoints | Custom Metadata Types / Named Credentials |
| Logic in triggers | Delegate to service/handler classes |
| DML inside loops | Collect records, single DML outside loop |
| `System.debug` for error logging | Custom log object + monitoring |
